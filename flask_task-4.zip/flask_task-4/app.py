import os
import string
import random
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from urllib.parse import urlparse

app = Flask(__name__)

# ---------------- URL VALIDATION ----------------
def is_valid_url(url):
    parsed = urlparse(url)
    return bool(parsed.scheme and parsed.netloc)

# ---------------- DATABASE CONFIG ----------------
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
Migrate(app, db)

# ---------------- MODEL ----------------
class ShortURL(db.Model):
    __tablename__ = "short_urls"

    id = db.Column(db.Integer, primary_key=True)
    original_url = db.Column(db.Text, nullable=False)
    short_code = db.Column(db.String(6), unique=True, nullable=False)

# ---------------- SHORT CODE GENERATOR ----------------
def generate_short_code():
    chars = string.ascii_letters + string.digits
    while True:
        code = ''.join(random.choice(chars) for _ in range(6))
        if not ShortURL.query.filter_by(short_code=code).first():
            return code

# ---------------- HOME / SHORTEN ----------------
@app.route('/', methods=['GET', 'POST'])
def shorten():
    if request.method == 'POST':
        original_url = request.form.get('url')

        # URL validation
        if not is_valid_url(original_url):
            return render_template(
                'shorten.html',
                error="Please enter a valid URL"
            )

        short_code = generate_short_code()
        new_url = ShortURL(
            original_url=original_url,
            short_code=short_code
        )

        db.session.add(new_url)
        db.session.commit()

        return render_template(
            'shorten.html',
            short_url=request.host_url + short_code
        )

    urls = ShortURL.query.all()
    return render_template('shorten.html', urls=urls)

# ---------------- REDIRECT ----------------
@app.route('/<short_code>')
def redirect_to_url(short_code):
    url = ShortURL.query.filter_by(short_code=short_code).first_or_404()
    return redirect(url.original_url)

# ---------------- HISTORY ----------------
@app.route('/history')
def history():
    urls = ShortURL.query.all()
    return render_template('history.html', urls=urls)

# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)
