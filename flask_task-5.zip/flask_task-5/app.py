import os
import string
import random
from urllib.parse import urlparse

from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import (
    LoginManager, UserMixin,
    login_required, login_user,
    logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# ---------------- CONFIGURATION ----------------
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'data.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'mykey'

db = SQLAlchemy(app)
Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# ---------------- HELPERS ----------------
def is_valid_url(url):
    parsed = urlparse(url)
    return bool(parsed.scheme and parsed.netloc)

def generate_short_code():
    chars = string.ascii_letters + string.digits
    while True:
        code = ''.join(random.choice(chars) for _ in range(6))
        if not ShortURL.query.filter_by(short_code=code).first():
            return code

# ---------------- MODELS ----------------
class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(9), unique=True, index=True)
    password_hash = db.Column(db.String(128))

    def __init__(self, username, password):
        self.username = username
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Sabji(db.Model):
    __tablename__ = "sabjis"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text)
    mrp = db.Column(db.Integer)


class ShortURL(db.Model):
    __tablename__ = "short_urls"

    id = db.Column(db.Integer, primary_key=True)
    original_url = db.Column(db.Text, nullable=False)
    short_code = db.Column(db.String(6), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

# ---------------- LOGIN LOADER ----------------
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------------- ROUTES ----------------
@app.route('/')
def index():
    return render_template('index.html')

# -------- REGISTER --------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('password')

        if len(username) < 5 or len(username) > 9:
            return render_template(
                'register.html',
                error="Username must be between 5 to 9 characters long"
            )

        if User.query.filter_by(username=username).first():
            return render_template(
                'register.html',
                error="This username already exists"
            )

        user = User(username, password)
        db.session.add(user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('register.html')

# -------- LOGIN --------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        user = User.query.filter_by(
            username=request.form.get('username')
        ).first()

        if user and user.check_password(request.form.get('password')):
            login_user(user)
            return redirect(url_for('shorten'))

        return render_template(
            'login.html',
            error="Invalid username or password"
        )

    return render_template('login.html')

# -------- URL SHORTENER (ADVANCED) --------
@app.route('/shorten', methods=['GET', 'POST'])
@login_required
def shorten():
    if request.method == "POST":
        original_url = request.form.get('url')

        if not is_valid_url(original_url):
            return render_template(
                'shorten.html',
                error="Please enter a valid URL"
            )

        short_code = generate_short_code()
        new_url = ShortURL(
            original_url=original_url,
            short_code=short_code,
            user_id=current_user.id
        )

        db.session.add(new_url)
        db.session.commit()

        return render_template(
            'shorten.html',
            short_url=request.host_url + short_code
        )

    urls = ShortURL.query.filter_by(user_id=current_user.id).all()
    return render_template('shorten.html', urls=urls)

# -------- REDIRECT --------
@app.route('/<short_code>')
def redirect_url(short_code):
    url = ShortURL.query.filter_by(short_code=short_code).first_or_404()
    return redirect(url.original_url)

# -------- LOGOUT --------
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# -------- OPTIONAL SABJI ROUTES --------
@app.route('/add', methods=['GET', 'POST'])
@login_required
def add():
    if request.method == "POST":
        name = request.form.get('name')
        mrp = request.form.get('mrp')
        sabji = Sabji(name=name, mrp=mrp)
        db.session.add(sabji)
        db.session.commit()
        return render_template('add.html', success="Sabji added successfully")
    return render_template('add.html')

@app.route('/display')
@login_required
def display_all():
    sabjis = Sabji.query.all()
    return render_template('display.html', sabjis=sabjis)

# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)
